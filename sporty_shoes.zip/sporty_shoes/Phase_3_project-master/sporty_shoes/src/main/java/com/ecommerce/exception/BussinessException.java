package com.ecommerce.exception;

public class BussinessException extends Exception{

	public BussinessException() {
		super();
		
	}

	public BussinessException(final String message) {
		super(message);
		
	}

}
